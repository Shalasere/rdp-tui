Machine-oriented companion to `rdp-tui-architecture-contract-final.md`. Not written for prose readability — written to be loaded into a coding agent's context alongside a task.

Read order for an implementing agent:

1. `00-manifest.yaml` — module list, dependency graph, forbidden edges, file layout.
2. `01-types.yaml` — target type shapes per module.
3. `02-rules.yaml` — invariants (binding), decisions (with rationale pointers), anti-patterns (grep-able failure signatures). Check generated code against this file specifically before considering any module done.
4. `03-process.yaml` — XDG paths, command templates, CLI command table, diagnostic tier definitions, full test matrix, phase plan.

If a generated change violates an entry in `02-rules.yaml`, that's a contract violation regardless of whether tests pass — fix it before moving on. `id` fields (`INV-*`, `DEC-*`, `AP-*`) are stable references; cite them in code comments or commit messages when a piece of code exists specifically to satisfy one (e.g. `// see DEC-lock-primitive`).
